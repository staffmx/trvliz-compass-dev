
import React, { useState } from 'react';
import { api } from '../services/api';

interface LoginProps {
  onLogin: (user: any) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const [view, setView] = useState<'login' | 'forgot'>('login');
  const [success, setSuccess] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const { data, error: signInError } = await api.signIn(email.trim(), password.trim());

      if (signInError) {
        if (signInError.message.includes("Invalid login credentials")) {
          setError("Credenciales inválidas. Por favor verifica tu correo y contraseña.");
        } else if (signInError.message.includes("Email not confirmed")) {
          setError("Por favor confirma tu correo electrónico antes de entrar.");
        } else {
          setError(signInError.message);
        }
        setIsLoading(false);
        return;
      }
      
    } catch (err: any) {
      console.error("Login catch:", err);
      setError("Error de conexión. Intenta de nuevo.");
      setIsLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const { error: resetError } = await api.resetPasswordForEmail(email.trim());
      if (resetError) {
        setError(resetError.message);
      } else {
        setSuccess("Se ha enviado un enlace de recuperación a tu correo electrónico.");
      }
    } catch (err: any) {
      setError("Ocurrió un error. Intenta de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-cover bg-center" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1436491865332-7a61a109cc05?q=80&w=2074&auto=format&fit=crop')" }}>
      <div className="absolute inset-0 bg-brand/80 backdrop-blur-sm"></div>
      
      <div className="relative z-10 w-full max-w-md p-10 bg-brand/95 backdrop-blur-md rounded-none shadow-2xl animate-fade-in-up m-4 border border-white/10">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-8">
              <img 
                  src="https://traveliz.com/trvconnect/16-547x184.png" 
                  alt="TRV Connect Logo" 
                  className="h-20 sm:h-28 w-auto object-contain"
              />
          </div>
          <p className="text-secondary text-xs tracking-[4px] uppercase font-semibold">Intranet Corporativa</p>
        </div>

        {view === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-8">
            <div>
              <label className="block text-xs font-bold text-gray-300 mb-2 ml-1 uppercase tracking-widest">Correo Corporativo</label>
              <div className="relative group">
                <span className="absolute left-3 top-4 text-secondary group-focus-within:text-white transition-colors">
                  <i className="fa-regular fa-envelope"></i>
                </span>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3.5 bg-black/20 border border-white/10 rounded-none text-white placeholder-secondary focus:ring-1 focus:ring-accent focus:border-accent outline-none transition-all"
                  placeholder="nombre@traveliz.com"
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-2 ml-1">
                <label className="block text-xs font-bold text-gray-300 uppercase tracking-widest">Contraseña</label>
                <button 
                  type="button" 
                  onClick={() => setView('forgot')}
                  className="text-[10px] text-accent hover:text-white transition-colors uppercase font-bold tracking-widest"
                >
                  ¿Olvidaste tu contraseña?
                </button>
              </div>
              <div className="relative group">
                <span className="absolute left-3 top-4 text-secondary group-focus-within:text-white transition-colors">
                  <i className="fa-solid fa-lock"></i>
                </span>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3.5 bg-black/20 border border-white/10 rounded-none text-white placeholder-secondary focus:ring-1 focus:ring-accent focus:border-accent outline-none transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className="p-4 rounded-none bg-red-900/20 border border-red-900/30 text-red-300 text-sm flex items-center animate-shake">
                <i className="fa-solid fa-circle-exclamation mr-2"></i>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-4 bg-surface text-brand hover:text-accent font-bold uppercase tracking-[2px] rounded-none shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 mt-6 text-sm group"
            >
              {isLoading ? (
                <>
                  <i className="fa-solid fa-circle-notch fa-spin"></i>
                  Iniciando sesión...
                </>
              ) : (
                <>
                  Entrar a Compass
                  <i className="fa-solid fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                </>
              )}
            </button>
          </form>
        ) : (
          <form onSubmit={handleResetPassword} className="space-y-8 animate-fade-in">
            <h3 className="text-white text-lg font-serif text-center mb-2">Recuperar Acceso</h3>
            <p className="text-secondary text-xs text-center mb-8 leading-relaxed">
              Ingresa tu correo electrónico y te enviaremos un enlace para restablecer tu contraseña.
            </p>

            <div>
              <label className="block text-xs font-bold text-gray-300 mb-2 ml-1 uppercase tracking-widest">Correo Corporativo</label>
              <div className="relative group">
                <span className="absolute left-3 top-4 text-secondary group-focus-within:text-white transition-colors">
                  <i className="fa-regular fa-envelope"></i>
                </span>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3.5 bg-black/20 border border-white/10 rounded-none text-white placeholder-secondary focus:ring-1 focus:ring-accent focus:border-accent outline-none transition-all"
                  placeholder="nombre@traveliz.com"
                />
              </div>
            </div>

            {error && (
              <div className="p-4 rounded-none bg-red-900/20 border border-red-900/30 text-red-300 text-sm flex items-center animate-shake">
                <i className="fa-solid fa-circle-exclamation mr-2"></i>
                {error}
              </div>
            )}

            {success && (
              <div className="p-4 rounded-none bg-green-900/20 border border-green-900/30 text-green-300 text-sm flex items-center">
                <i className="fa-solid fa-circle-check mr-2"></i>
                {success}
              </div>
            )}

            <div className="space-y-4">
              <button
                type="submit"
                disabled={isLoading || !!success}
                className="w-full py-4 bg-surface text-brand hover:text-accent font-bold uppercase tracking-[2px] rounded-none shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-300 flex items-center justify-center gap-2 text-sm group"
              >
                {isLoading ? (
                  <>
                    <i className="fa-solid fa-circle-notch fa-spin"></i>
                    Enviando...
                  </>
                ) : (
                  <>
                    Enviar enlace de recuperación
                    <i className="fa-solid fa-paper-plane group-hover:translate-x-1 transition-transform"></i>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => { setView('login'); setError(''); setSuccess(''); }}
                className="w-full py-3 text-white/60 hover:text-white text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-arrow-left"></i> Volver al inicio
              </button>
            </div>
          </form>
        )}

        <div className="mt-10 text-center border-t border-white/5 pt-8">
          <p className="text-xs text-secondary leading-relaxed">
            © 2026 Traveliz Agency. <br/>Exclusivo uso interno.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;

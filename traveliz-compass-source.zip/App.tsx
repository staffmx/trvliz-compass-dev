
import React, { useState, useEffect } from 'react';
import Login from './components/Login';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Inspiration from './components/Inspiration';
import Directory from './components/Directory';
import AssociateProfile from './components/AssociateProfile';
import Training from './components/Training';
import EventsCalendar from './components/EventsCalendar';
import EventDetail from './components/EventDetail';
import AdminPanel from './components/AdminPanel';
import Documentation from './components/Documentation';
import ProvidersList from './components/ProvidersList';
import ProviderDetail from './components/ProviderDetail';
import NoticeDetail from './components/NoticeDetail';
import NoticesList from './components/NoticesList';
import MyProfile from './components/MyProfile';
import PublicPostView from './components/PublicPostView';
import NotificationsList from './components/NotificationsList';
import SearchResults from './components/SearchResults';
import { User, NavigationItem, SearchResults as SearchResultsType } from './types';
import { api } from './services/api';

const PlaceholderPage: React.FC<{ title: string; icon: string }> = ({ title, icon }) => (
  <div className="max-w-site mx-auto px-mobile-x py-section-y text-center animate-fade-in">
    <div className="w-24 h-24 bg-white border border-gray-200 rounded-full flex items-center justify-center mx-auto mb-6 text-secondary shadow-sm">
      <i className={`fa-solid ${icon} text-4xl`}></i>
    </div>
    <h2 className="text-3xl font-serif text-primary mb-3">{title}</h2>
    <p className="text-secondary text-lg font-light">Esta sección está actualmente bajo construcción.</p>
  </div>
);

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [currentNav, setCurrentNav] = useState<NavigationItem>(NavigationItem.DASHBOARD);
  const [selectedEventId, setSelectedEventId] = useState<number | null>(null);
  const [selectedAssociateId, setSelectedAssociateId] = useState<number | null>(null);
  const [selectedNoticeId, setSelectedNoticeId] = useState<string | null>(null);
  const [selectedBlogId, setSelectedBlogId] = useState<number | null>(null);
  const [searchResults, setSearchResults] = useState<SearchResultsType | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<any | null>(null);
  const [renderPublicPostId, setRenderPublicPostId] = useState<number | null>(null);
  
  // Provider Filter States (Elevated for persistence)
  const [providerSearchTerm, setProviderSearchTerm] = useState('');
  const [providerSelectedServiceTypes, setProviderSelectedServiceTypes] = useState<string[]>([]);
  const [providerSelectedTypes, setProviderSelectedTypes] = useState<string[]>([]);
  const [providerSelectedPlatforms, setProviderSelectedPlatforms] = useState<string[]>([]);
  const [providerSelectedRegions, setProviderSelectedRegions] = useState<string[]>([]);

  const [isRecoveringPassword, setIsRecoveringPassword] = useState(false);

  useEffect(() => {
    // 0. Verificar si es una vista pública de compartido
    const params = new URLSearchParams(window.location.search);
    const postIdStr = params.get('post');
    if (postIdStr) {
      const pId = parseInt(postIdStr, 10);
      if (!isNaN(pId)) {
        setRenderPublicPostId(pId);
        // No verificamos sesión técnica si es vista pública, pero el efecto de auth seguirá corriendo
      }
    }

    // 1. Verificar sesión inicial
    api.getCurrentSession().then(session => {
      if (session) {
        handleProfileSync(session.user.id, session.user.email);
      }
    });

    // 2. Escuchar cambios de autenticación
    const subscription = api.subscribeToAuth((event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        setIsRecoveringPassword(true);
      }

      if (session) {
        handleProfileSync(session.user.id, session.user.email);
      } else {
        setUser(null);
        setIsAuthenticated(false);
      }
    });

    return () => {
      if (subscription) subscription.unsubscribe();
    };
  }, []);

  // 3. Reiniciar scroll al cambiar de sección o detalle
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [
    currentNav, 
    selectedEventId, 
    selectedAssociateId, 
    selectedNoticeId, 
    selectedBlogId, 
    selectedProvider,
    searchResults
  ]);

  // 4. Bloquear el botón de "Atrás" del navegador
  useEffect(() => {
    // Inyectamos un estado extra al inicio
    window.history.pushState(null, "", window.location.href);

    const handlePopState = () => {
      // Forzamos al navegador a ir "adelante" inmediatamente después de que intentó ir "atrás"
      window.history.go(1);
    };

    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  const handlePasswordUpdate = async (newPassword: string) => {
    try {
      const { error } = await api.updatePassword(newPassword);
      if (error) throw error;
      alert("Contraseña actualizada con éxito.");
      setIsRecoveringPassword(false);
    } catch (err: any) {
      alert("Error al actualizar la contraseña: " + err.message);
    }
  };

  const handleProfileSync = async (userId: string, email?: string) => {
    try {
      const profile = await api.getUserProfile(userId, email);
      
      if (profile) {
        // Mapear UserProfile a User
        const adminRoleNames = ['admin', 'administrador', 'super_admin', 'superadmin', 'administrador maestro'];
        const userRoles = (profile.roles || []).map(r => (r?.name || '').toLowerCase());
        const hasAdminRole = userRoles.some(name => adminRoleNames.includes(name));
        const isActuallySuper = userRoles.includes('super_admin') || userRoles.includes('superadmin') || profile.email === 'yibrant@internationalcruises.mx';

        const userData: User = {
          id: profile.id,
          name: profile.name,
          email: profile.email,
          role: (hasAdminRole || profile.email === 'yibrant@internationalcruises.mx') ? 'admin' : 'employee',
          isSuperAdmin: isActuallySuper,
          roles: profile.roles || [],
          avatar: profile.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(profile.name || 'U')}&background=random`
        };
        setUser(userData);
        setIsAuthenticated(true);
      } else {
        // EXCEPCIÓN DE SEGURIDAD PARA ADMINISTRADOR MAESTRO
        if (email === 'yibrant@internationalcruises.mx') {
          const adminUser: User = {
            id: userId,
            name: 'Yibrant Medina',
            email: email,
            role: 'admin',
            isSuperAdmin: true,
            roles: [],
            avatar: `https://ui-avatars.com/api/?name=Yibrant&background=random`
          };
          setUser(adminUser);
          setIsAuthenticated(true);
        } else {
          // PERFIL NO ENCONTRADO (Posiblemente usuario eliminado o desactivado del sistema)
          console.warn("No se encontró perfil asociado para este usuario de Auth. Acceso denegado.");
          await api.signOut();
          setUser(null);
          setIsAuthenticated(false);
          // Pequeño delay para asegurar que el signOut procesa en la UI antes de la alerta
          setTimeout(() => {
            alert("Tu cuenta no tiene un perfil asociado o ha sido desactivada del sistema.\n\nPor favor, contacta al administrador si consideras que esto es un error.");
          }, 100);
        }
      }
    } catch (err) {
      console.error("Error syncing profile:", err);
      setIsAuthenticated(false);
    }
  };

  const handleLogin = (userData: User) => {
    // Esta función ahora será llamada indirectamente por el listener o tras el signIn
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = async () => {
    await api.signOut();
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('traveliz_user'); // Limpiar por si acaso había basura
    setCurrentNav(NavigationItem.DASHBOARD);
  };

  const handleSearch = async (term: string) => {
    if (!term.trim()) return;
    
    setSearchTerm(term);
    setIsSearching(true);
    setCurrentNav(NavigationItem.SEARCH_RESULTS);
    
    try {
      const results = await api.search(term, user ? { id: user.id, name: user.name } : undefined);
      setSearchResults(results);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleNavigateToEvent = (eventId: number) => {
    setSelectedEventId(eventId);
    setCurrentNav(NavigationItem.EVENT_DETAIL);
  };
  
  const handleNavigateToNotice = (noticeId: string) => {
    setSelectedNoticeId(noticeId);
    setCurrentNav(NavigationItem.NOTICE_DETAIL);
  };

  const handleViewAssociate = (id: number) => {
    setSelectedAssociateId(id);
    setCurrentNav(NavigationItem.ASSOCIATE_DETAIL);
  };

  const handleNavigateToBlog = (postId: number) => {
    setSelectedBlogId(postId);
    setCurrentNav(NavigationItem.BLOG);
  };

  const renderContent = () => {
    switch (currentNav) {
      case NavigationItem.DASHBOARD:
        return <Dashboard 
            user={user!} 
            onNavigate={setCurrentNav} 
            onEventClick={handleNavigateToEvent}
            onNoticeClick={handleNavigateToNotice}
            onBlogClick={handleNavigateToBlog}
        />;
      case NavigationItem.AVISOS:
        return <NoticesList 
            user={user!}
            onNavigate={setCurrentNav} 
            onEventClick={handleNavigateToEvent}
        />;
      case NavigationItem.NOTICE_DETAIL:
        return selectedNoticeId ? (
            <NoticeDetail 
                noticeId={selectedNoticeId} 
                user={user!}
                onBack={() => setCurrentNav(NavigationItem.DASHBOARD)} 
            />
        ) : <PlaceholderPage title="Aviso no encontrado" icon="fa-triangle-exclamation" />;
      case NavigationItem.DOCUMENTACION:
        return <Documentation user={user!} />;
      case NavigationItem.PROVEEDORES:
        return selectedProvider ? (
          <ProviderDetail 
            provider={selectedProvider} 
            onBack={() => setSelectedProvider(null)} 
          />
        ) : (
          <ProvidersList 
            user={user!}
            onSelectProvider={setSelectedProvider}
            searchTerm={providerSearchTerm}
            setSearchTerm={setProviderSearchTerm}
            selectedServiceTypes={providerSelectedServiceTypes}
            setSelectedServiceTypes={setProviderSelectedServiceTypes}
            selectedProviderTypes={providerSelectedTypes}
            setSelectedProviderTypes={setProviderSelectedTypes}
            selectedPlatforms={providerSelectedPlatforms}
            setSelectedPlatforms={setProviderSelectedPlatforms}
            selectedRegions={providerSelectedRegions}
            setSelectedRegions={setProviderSelectedRegions}
          />
        );
      case NavigationItem.BLOG:
        return <Inspiration 
            user={user!} 
            onNavigate={setCurrentNav} 
            initialPostId={selectedBlogId}
            onClearInitialPost={() => setSelectedBlogId(null)}
        />;
      case NavigationItem.DIRECTORIO:
        return <Directory onViewProfile={handleViewAssociate} />;
      case NavigationItem.ASSOCIATE_DETAIL:
        return selectedAssociateId ? (
            <AssociateProfile associateId={selectedAssociateId} onBack={() => setCurrentNav(NavigationItem.DIRECTORIO)} />
        ) : <Directory onViewProfile={handleViewAssociate} />;
      case NavigationItem.CAPACITACION:
        return <Training user={user!} />;
      case NavigationItem.CALENDARIO:
        return <EventsCalendar onEventClick={handleNavigateToEvent} />;
      case NavigationItem.EVENT_DETAIL:
        return selectedEventId ? (
          <EventDetail 
            eventId={selectedEventId} 
            user={user!} 
            onBack={() => setCurrentNav(NavigationItem.CALENDARIO)} 
          />
        ) : (
          <EventsCalendar onEventClick={handleNavigateToEvent} />
        );
      case NavigationItem.ADMIN:
        return <AdminPanel user={user!} />;
      case NavigationItem.MY_PROFILE:
        return <MyProfile user={user!} onBack={() => setCurrentNav(NavigationItem.DASHBOARD)} onUserUpdate={setUser} />;
      case NavigationItem.NOTIFICATIONS:
        return <NotificationsList user={user!} />;
      case NavigationItem.SEARCH_RESULTS:
        return isSearching ? (
          <div className="flex flex-col items-center justify-center py-32 animate-fade-in">
            <div className="w-12 h-12 border-2 border-accent border-t-transparent rounded-full animate-spin mb-6"></div>
            <p className="text-secondary font-light tracking-widest uppercase text-[10px]">Buscando en el universo Traveliz...</p>
          </div>
        ) : searchResults ? (
          <SearchResults 
            results={searchResults} 
            searchTerm={searchTerm}
            onNavigate={setCurrentNav}
            onEventClick={handleNavigateToEvent}
            onNoticeClick={handleNavigateToNotice}
            onViewProfile={handleViewAssociate}
            onBlogClick={handleNavigateToBlog}
          />
        ) : <PlaceholderPage title="No hay resultados" icon="fa-magnifying-glass" />;
      default:
        return <Dashboard 
            user={user!} 
            onNavigate={setCurrentNav} 
            onEventClick={handleNavigateToEvent}
            onNoticeClick={handleNavigateToNotice}
        />;
    }
  };

  if (isRecoveringPassword) {
    return (
      <div className="min-h-screen bg-brand flex items-center justify-center p-4">
        <div className="w-full max-w-md p-10 bg-brand border border-white/10 shadow-2xl backdrop-blur-md">
          <div className="text-center mb-8">
            <img 
              src="https://traveliz.com/trvconnect/16-547x184.png" 
              alt="TRV Connect" 
              className="h-20 w-auto mx-auto mb-6 object-contain"
            />
            <h3 className="text-white text-xl font-serif">Nueva Contraseña</h3>
            <p className="text-secondary text-xs mt-2 uppercase tracking-widest">Establece tu nuevo acceso</p>
          </div>
          
          <form onSubmit={(e) => {
            e.preventDefault();
            const pwd = (e.currentTarget.elements.namedItem('new_password') as HTMLInputElement).value;
            handlePasswordUpdate(pwd);
          }} className="space-y-6">
            <div>
              <label className="block text-[10px] font-bold text-gray-400 mb-2 uppercase tracking-widest">Nueva Contraseña</label>
              <input
                name="new_password"
                type="password"
                required
                minLength={6}
                className="w-full px-4 py-3 bg-black/20 border border-white/10 text-white focus:border-accent outline-none transition-all rounded-none"
                placeholder="••••••••"
              />
            </div>
            <button
              type="submit"
              className="w-full py-4 bg-white text-brand font-bold uppercase tracking-widest hover:bg-accent transition-colors duration-300 text-xs"
            >
              Actualizar Contraseña
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (renderPublicPostId) {
    return <PublicPostView postId={renderPublicPostId} />;
  }

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-background flex flex-col font-sans text-primary">
      <Header 
        user={user!} 
        onLogout={handleLogout} 
        currentNav={currentNav}
        onNavigate={setCurrentNav}
        onSearch={handleSearch}
        onNoticeClick={handleNavigateToNotice}
      />
      
      <main className="flex-grow">
        {renderContent()}
      </main>

      <footer className="bg-primary border-t border-white/5 pt-16 pb-8 mt-16">
        <div className="max-w-site mx-auto px-mobile-x">
            <div className="flex flex-col lg:flex-row gap-12 lg:gap-8 mb-16 justify-between">
                <div className="lg:w-[44%] space-y-6">
                    <div className="mb-4">
                        <img 
                            src="https://traveliz.com/new-2025/wp-content/uploads/2026/01/logo-vert-traveliz-1.png" 
                            alt="Traveliz" 
                            className="h-24 w-auto object-contain opacity-90"
                        />
                    </div>
                    <p className="text-secondary text-sm leading-luxury font-light max-w-md">
                        Redefiniendo el viaje de lujo a través de una lente de elegancia, sutileza y conexión emocional. Tu mundo, a tu medida.
                    </p>
                </div>

                <div className="lg:w-[28%] space-y-6">
                    <h5 className="font-serif text-white text-lg font-medium">Mapa de Sitio</h5>
                    <ul className="space-y-3">
                        <li><button onClick={() => setCurrentNav(NavigationItem.AVISOS)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Avisos</button></li>
                        <li><button onClick={() => setCurrentNav(NavigationItem.DOCUMENTACION)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Documentación</button></li>
                        <li><button onClick={() => setCurrentNav(NavigationItem.BLOG)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Inspiración</button></li>
                        <li><button onClick={() => setCurrentNav(NavigationItem.DIRECTORIO)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Directorio</button></li>
                        <li><button onClick={() => setCurrentNav(NavigationItem.CAPACITACION)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Capacitación</button></li>
                        <li><button onClick={() => setCurrentNav(NavigationItem.CALENDARIO)} className="text-secondary hover:text-accent transition-colors text-sm tracking-wide flex items-center gap-2 group">Calendario</button></li>
                    </ul>
                </div>

                <div className="lg:w-[28%] space-y-6">
                    <h5 className="font-serif text-white text-lg font-medium">Contacto</h5>
                    <ul className="space-y-5">
                        <li className="flex items-start gap-3 text-secondary group cursor-default">
                            <div className="w-8 h-8 rounded-none bg-white/5 flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-colors flex-shrink-0">
                                <i className="fa-solid fa-envelope text-xs"></i>
                            </div>
                            <div className="flex flex-col">
                                <span className="text-[10px] uppercase tracking-widest text-gray-500 mb-0.5">Email</span>
                                <span className="text-sm font-light text-gray-300">soporte@traveliz.com</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <div className="border-t border-white/5 pt-8 text-center">
                <p className="text-sm text-secondary font-light tracking-wide">© 2026 Traveliz. Todos los derechos reservados.</p>
                <p className="text-xs text-gray-500 mt-2 uppercase tracking-widest">Exclusivo uso interno.</p>
            </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
